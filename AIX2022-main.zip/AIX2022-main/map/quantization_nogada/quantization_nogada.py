import numpy as np
import matplotlib.pyplot as plt

from quantization_function import fake_quantize, quantize


def main():
    filename = "./weight.txt"
    weights = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        for line in lines:
            weights.append(float(line))
    weights = np.array(weights, dtype=np.float32)

    # fake_quantization_nogada(weights)
    quantization_nogada(weights)


def fake_quantization_nogada(r_array: np.ndarray) -> np.ndarray:
    """
    r_array: float32 타입의 ndarray.
    output: int8 타입의 ndarray.
    """
    max_r = r_array.max()
    min_r = r_array.min()
    s_mean = (max_r - min_r) / 255
    z_mean = (max_r + min_r) / 2

    # s_linspace = np.linspace(s_mean * 0.5, s_mean * 1.5, num=100)
    # s_linspace = np.linspace(s_mean * 0.8, s_mean * 1.2, num=100)
    # s_linspace = np.linspace(s_mean * 1, s_mean * 1.2, num=100)
    s_linspace = np.linspace(s_mean * 1, s_mean * 1.5, num=100)

    z_linspace = np.linspace(z_mean * 0.5, z_mean * 1.5, num=100)
    # z_linspace = np.linspace(z_mean * 0.8, z_mean * 1.2, num=100)
    # z_linspace = np.linspace(z_mean * 0.8, z_mean * 1.2, num=100)
    
    results = np.ndarray((100, 100))
    for i, s in enumerate(s_linspace):
        for j, z in enumerate(z_linspace):
            quant_error = []
            for r in r_array:
                q = fake_quantize(r, s, z)
                r_quantized = q * s + z
                quant_error.append(r - r_quantized)
            quant_error = np.array(quant_error)
            results[i, j] = np.linalg.norm(quant_error) ** 2  # 오차의 제곱합

    # print(results[:20, :20])
    results *= 10000

    xx, yy = np.meshgrid(z_linspace, s_linspace)
    fig, ax = plt.subplots()
    ax.pcolormesh(xx, yy, results, cmap='brg')

    plt.show()


def quantization_nogada(r_array: np.ndarray) -> np.ndarray:
    """
    r_array: float32 타입의 ndarray.
    output: int8 타입의 ndarray.
    """
    max_r = r_array.max()
    min_r = r_array.min()
    s_mean = (max_r - min_r) / 255
    z_mean = (max_r + min_r) / 2

    s_linspace = np.linspace(s_mean * 0.5, s_mean * 1.5, num=100)
    # s_linspace = np.linspace(s_mean * 0.8, s_mean * 1.2, num=100)
    # s_linspace = np.linspace(s_mean * 1, s_mean * 1.2, num=100)
    # s_linspace = np.linspace(s_mean * 1, s_mean * 1.5, num=100)

    z_linspace = np.arange(-128, 128)

    results = np.ndarray((100, 256))
    for i, s in enumerate(s_linspace):
        for j, z in enumerate(z_linspace):
            quant_error = []
            for r in r_array:
                q = quantize(r, s, z)
                r_quantized = (q - z) * s
                quant_error.append(r - r_quantized)
            quant_error = np.array(quant_error)
            results[i, j] = np.linalg.norm(quant_error) ** 2  # 오차의 제곱합

    s_index, z_index = np.unravel_index(results.argmin(), results.shape)
    S = s_linspace[s_index]
    Z = z_linspace[z_index]
    print(results[s_index, z_index], S, Z)

    # print(results[:20, :20])
    # results = np.log(results)

    xx, yy = np.meshgrid(z_linspace, s_linspace)
    fig, ax = plt.subplots()
    ax.pcolormesh(xx, yy, results, cmap='brg')
    # fig = plt.figure()
    # ax = plt.axes(projection='3d')
    # ax.plot_surface(xx, yy, results)

    plt.show()


if __name__ == '__main__':
    main()
