import numpy as np


def fake_quantize(r: float, s: float, z: float) -> int:
    q = round((r - z) / s)
    if q < -128:
        q = -128
    elif q > 127:
        q = 127
    return q

def quantize(r: float, s: float, z: int) -> int:
    q = round(r / s) + z
    if q < -128:
        q = -128
    elif q > 127:
        q = 127
    return q

def quantize_with_multiplier(r: float, s: float) -> int:
    q = round(r * s)
    if q < -128:
        q = -128
    elif q > 127:
        q = 127
    return q


if __name__ == '__main__':
    pass
