import numpy as np
import matplotlib.pyplot as plt

from quantization_function import quantize_with_multiplier
from weights_parse import parse_weights

def main():
    biases, weights = parse_weights()
    weight_part = weights[5].ravel()
    # print(weight_part)
    quantization_nogada(weight_part)


def quantization_nogada(r_array: np.ndarray) -> np.ndarray:
    """
    r_array: float32 타입의 ndarray.
    output: int8 타입의 ndarray.
    """
    max_r = r_array.max()
    min_r = r_array.min()
    print(max_r, min_r)
    multiplier_mean = 255 / (max_r - min_r)

    mul_linspace = np.linspace(multiplier_mean * 0.9, multiplier_mean * 1.4, num=100)

    results = np.zeros_like(mul_linspace)
    for i, mul in enumerate(mul_linspace):
        quant_error = []
        for r in r_array:
            q = quantize_with_multiplier(r, mul)
            r_quantized = q / mul
            quant_error.append(r - r_quantized)
        quant_error = np.array(quant_error)
        results[i] = np.linalg.norm(quant_error)  # 오차의 L2 norm
        # results[i] = np.abs(quant_error).sum()  # 오차의 절댓값 합

    s_index, = np.unravel_index(results.argmin(), results.shape)
    s_peak = mul_linspace[s_index]
    norm_min = results[s_index]
    print(s_peak, norm_min)

    fig, ax = plt.subplots()
    ax.set_title("L2 norm of error (layer 10)")
    ax.plot(mul_linspace, results)  # s - norm 그래프
    ax.axvline(multiplier_mean, color='red', alpha=0.3)
    ax.annotate(f"perfect multiplier={multiplier_mean:5.2f}", (multiplier_mean, ax.get_ylim()[1]), color='red', xytext=(0, -100), textcoords='offset pixels', horizontalalignment='center')
    ax.plot(s_peak, norm_min, color='green', marker='o', alpha=0.3)  # 최소점
    ax.annotate(f"({s_peak:5.2f}, {norm_min:3.2f})", (s_peak, norm_min), color='green', xytext=(-15, -20), textcoords='offset pixels')  # 라벨링
    ax.plot(mul_linspace, np.zeros_like(mul_linspace) + norm_min, color='green', alpha=0.3)  # 수평선

    plt.show()


if __name__ == '__main__':
    main()
