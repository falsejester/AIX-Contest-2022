import math

import numpy as np
import matplotlib.pyplot as plt

from weights_parse import parse_weights

def main():
    biases, weights = parse_weights()
    show_weights(weights)


def show_weights(r_array: list[np.ndarray]) -> None:

    layer_index = [0, 2, 4, 6, 8, 10, 12, 13, 16, 19, 20]

    fig, axs = plt.subplots(nrows=2, ncols=4)
    # axs[2, 3].axis('off')
    # Layer 13, 16, 19, 20은 오류 있음
    # for l in range(11):
    for l in range(7):
        i = math.floor(l / 4)
        j = l % 4
        x = r_array[l].ravel()
        if l == 0:
            axs[i, j].set_title(f"Layer {layer_index[l]}")
            axs[i, j].hist(x, bins=1000, range=(-16, 16))
            axs[i, j].twinx().boxplot(x, sym='', vert=False)
            axs[i, j].twinx().scatter(x, np.zeros_like(x) + 1, c='blue', marker='x', alpha=0.5)
        else:
            axs[i, j].set_title(f"Layer {layer_index[l]}")
            axs[i, j].hist(x, bins=1000, range=(-1, 1))
            axs[i, j].twinx().boxplot(x, sym='', vert=False)
            axs[i, j].twinx().scatter(x, np.zeros_like(x) + 1, c='blue', marker='x', alpha=0.5)

    # Layer 13, 16, 19, 20은 오류 있음
    axs[1, 3].axis('off')
    # axs[2, 0].axis('off')
    # axs[2, 1].axis('off')
    # axs[2, 2].axis('off')
    plt.show()


if __name__ == '__main__':
    main()
