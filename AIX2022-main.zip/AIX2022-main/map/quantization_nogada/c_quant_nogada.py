import numpy as np
import matplotlib.pyplot as plt


def main():
    mul_arr, map_arr = [], []
    with open("weight_nogada_layer0.txt", 'r') as f:
        f.readline()
        f.readline()
        for line in f:
            if line:
                mul_str, map_str = line.split(',')
                mul_arr.append(float(mul_str))
                map_arr.append(float(map_str))
    mul_arr = np.array(mul_arr)
    map_arr = np.array(map_arr)
    show_weights(mul_arr, map_arr)


def show_weights(mul_arr: np.ndarray, map_arr: np.ndarray) -> None:
    mul_index, = np.unravel_index(map_arr.argmax(), map_arr.shape)
    mul_peak = mul_arr[mul_index]
    map_peak = map_arr[mul_index]

    fig, ax = plt.subplots()
    ax.set_title(f"Layer {0}")
    ax.plot(mul_arr, map_arr)
    ax.plot(mul_peak, map_peak, color='green', marker='o', alpha=0.3)  # 최대점
    ax.annotate(f"({mul_peak:.2f}, {map_peak*100:.2f})", (mul_peak, map_peak), color='green', xytext=(-15, 10), textcoords='offset pixels')  # 라벨링
    ax.plot(mul_arr, np.zeros_like(mul_arr) + map_peak, color='green', alpha=0.3)  # 수평선

    plt.show()


if __name__ == '__main__':
    main()
