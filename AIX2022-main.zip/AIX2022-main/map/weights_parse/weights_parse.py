import struct

import numpy as np


def parse_weights(weights_filepath = r"D:\AIX2022\skeleton\bin\yolov3-tiny-aix2022.weights"):
    config_filepath = r"D:\AIX2022\skeleton\bin\yolov3-tiny-aix2022.cfg"

    num_filters = [16, 32, 64, 128, 128, 128, 128, 195, 128, 128, 195]
    num_input_channels = [3, 16, 32, 64, 128, 128, 128, 128, 128, 256, 128]
    num_filter_sizes = [3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 1]
    biases = [None] * 11
    scales = [None] * 11
    rlmean = [None] * 11
    rlvar = [None] * 11
    weights = [None] * 11

    with open(weights_filepath, 'rb') as f:
        # Headers
        major = f.read(4)
        major = int.from_bytes(major, 'big')
        minor = f.read(4)
        minor = int.from_bytes(minor, 'big')
        revision = f.read(4)
        revision = int.from_bytes(revision, 'big')
        seen = f.read(8)
        # seen = struct.unpack('>f', seen)

        # Convolutional layer는 총 11개.
        for l in range(11):
            biases_temp = f.read(4 * num_filters[l])
            biases[l] = np.frombuffer(biases_temp, 'float32')
            scales_temp = f.read(4 * num_filters[l])
            scales[l] = np.frombuffer(scales_temp, 'float32')
            rlmean_temp = f.read(4 * num_filters[l])
            rlmean[l] = np.frombuffer(rlmean_temp, 'float32')
            rlvar_temp = f.read(4 * num_filters[l])
            rlvar[l] = np.frombuffer(rlvar_temp, 'float32')
            weights_temp = f.read(4 * num_filters[l] * num_input_channels[l] * num_filter_sizes[l] * num_filter_sizes[l])
            weights[l] = np.frombuffer(weights_temp, 'float32')
            weights[l] = weights[l].copy()
            weights[l].resize((num_filters[l], num_input_channels[l], num_filter_sizes[l], num_filter_sizes[l]))

            for fil in range(num_filters[l]):
                biases[l] = biases[l] - scales[l][fil] * rlmean[l][fil] / (0.000001 + np.sqrt(rlvar[l][fil]))
                # print(weights[0][0].flags)
                weights[l][fil, ...] = weights[l][fil] * scales[l][fil] / (0.000001 + np.sqrt(rlvar[l][fil]))

    return biases, weights


def main():
    biases, weights = parse_weights()
    print(weights[1])


if __name__ == '__main__':
    main()