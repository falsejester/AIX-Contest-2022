import struct

def main():
    weights_filepath = r"./parsed.map"

    with open(weights_filepath, 'rb') as f:
        # Layer filter number -> 

        # Headers
        major = f.read(4)
        major = int.from_bytes(major, 'big')
        minor = f.read(4)
        minor = int.from_bytes(minor, 'big')
        revision = f.read(4)
        revision = int.from_bytes(revision, 'big')
        seen = f.read(8)
        seen = struct.unpack('>f', seen)

        # Convolutional layer는 총 11개.
        for l in ra


if __name__ == '__main__':
    main()